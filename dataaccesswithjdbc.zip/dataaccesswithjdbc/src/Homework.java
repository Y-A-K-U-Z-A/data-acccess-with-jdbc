import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

public class Homework {
    private static final String CONNECTION_STR = "jdbc:mysql://localhost:3306/";

    private static final String DB_NAME = "minions_db";
    private Connection connection;
    private String query;
    private PreparedStatement stmt;
    private final Scanner sc;

    public Homework() {
        sc = new Scanner(System.in);
    }

    public void getConnection(String username, String password) throws SQLException {
        Properties properties = new Properties();
        properties.setProperty("user", username);
        properties.setProperty("password", password);
        this.connection = DriverManager.getConnection(CONNECTION_STR + DB_NAME, properties);
    }

    public void getVillainsNames() throws SQLException {
        this.query = "select name, count(minion_id) from villains as v\n" +
                "join minions_villains mv on v.id = mv.villain_id\n" +
                "group by villain_id\n" +
                "having count(minion_id) > 15\n" +
                "order by count(minion_id) desc;";
        stmt = connection.prepareStatement(query);
        stmt.execute();
        ResultSet resultSet = stmt.getResultSet();
        while (resultSet.next()) {
            System.out.println(resultSet.getString(1) + " " + resultSet.getInt(2));
        }
    }


    public void getMinionNames() throws SQLException {
        System.out.println("Enter villain's id: ");
        int numberId = Integer.parseInt(sc.nextLine());
        this.query = "select name, age from minions as m\n" +
                "join minions_villains mv on m.id = mv.minion_id\n" +
                "where mv.villain_id = ?;";

        this.stmt = connection.prepareStatement(query);
        this.stmt.setInt(1, numberId);
        this.stmt.execute();
        ResultSet rs = stmt.getResultSet();
        if (!rs.next()) {
            System.out.println("No villain with ID " + numberId + " exists in the database.");
            return;
        }
        String name = getEntityNameById(numberId, "villains");

        System.out.println("Villain: " + name);
        int i = 0;
        while (rs.next()) {
            i++;
            System.out.println(i + ". " + rs.getString("name") + " " + rs.getInt("age"));
        }

    }

    private String getEntityNameById(int numberId, String tableName) throws SQLException {
        query = String.format("select name from %s  where id = ? ;", tableName);
        this.stmt = connection.prepareStatement(query);
        this.stmt.setInt(1, numberId);

        stmt.execute();
        ResultSet result = stmt.getResultSet();
        result.next();
        return result.getString(1);
    }

    public void changeTownNamesCasing() throws SQLException {
        System.out.println("Enter country: ");
        String country = sc.nextLine();
        query = String.format("update towns " +
                "set name = upper(name) " +
                "where country = '%s' ;", country);

        stmt = connection.prepareStatement(query);
        stmt.execute();

        query = String.format("select name from towns where country = '%s' ;", country);
        stmt = connection.prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_UPDATABLE);
        stmt.execute();
        ResultSet result = stmt.getResultSet();


        try {
            StringBuilder sb = new StringBuilder();
            int size = getResultsetSize(country);
            List<String> names = new ArrayList<>();
            sb.append(size).append(" town names were affected.").append(System.lineSeparator());

            result.next();
            do {
                String currRow = result.getString("name");
                names.add(currRow);
            } while (result.next());

            sb.append(names);
            System.out.println(sb.toString());
            return;
        } catch (SQLException e) {
            System.out.println("No town names were affected.");
            return;
        }
    }

    private int getResultsetSize(String nameCountry) throws SQLException {
        query = "select count(name) from towns " +
                "group by country " +
                "having country  = ? ;";
        stmt = connection.prepareStatement(query);
        stmt.setString(1, nameCountry);
        stmt.execute();
        ResultSet resultSet = stmt.getResultSet();
        resultSet.next();
        return resultSet.getInt(1);
    }

    public void addMinion() throws SQLException {
        System.out.println("Enter minions information: (name) (age) (town name)");
        String[] minInfo = sc.nextLine().split("\\s+");
        System.out.println("Enter villain's name: ");
        String[] villainInf = sc.nextLine().split("\\s+");

        String minName = minInfo[0];
        int minAge = Integer.parseInt(minInfo[1]);
        String townName = minInfo[2];

        String villName = villainInf[0];

        int townId = getEnityIdByName("towns", townName);

        if (townId < 0) {
            insertEntityInTowns(townName);
            System.out.println("Town " + townName + " was added to the database.");
        }

        int villId = getEnityIdByName("villains", villName);

        if (villId < 0) {
            insertVillainInVillains(villName);
            System.out.println("Villain " + villName + " was added to the database.");
        }
        int minId = getEnityIdByName("minions", minName);

        if (minId < 0) {
                insertMinion(minName, minAge, townId);
        }
            insertMinionToVillains(minId, villId, minName, villName);
    }


    private void insertMinionToVillains(int minId, int villId, String minName, String villName) throws SQLException {
        query = "insert into minions_villains(minion_id, villain_id) values (?,?)";
        this.stmt = connection.prepareStatement(query);
        this.stmt.setInt(1, minId);
        this.stmt.setInt(2, villId);
        this.stmt.executeUpdate();
        System.out.println("Successfully added " + minName + " to be minion of " + villName);
    }

    private void insertMinion(String minName, int minAge, int townId) throws SQLException {
        query = "insert into minions(name, age, town_id) values(?,?,?)";
        this.stmt = connection.prepareStatement(query);
        this.stmt.setString(1, minName);
        this.stmt.setInt(2, minAge);
        this.stmt.setInt(3, townId);
        this.stmt.executeUpdate();
    }

    private void insertVillainInVillains(String villName) throws SQLException {
        query = "insert into villains(name, evilness_factor) values (?,'evil')";
        this.stmt = connection.prepareStatement(query);
        this.stmt.setString(1, villName);
        this.stmt.executeUpdate();
    }

    private void insertEntityInTowns(String townName) throws SQLException {
        query = "insert into towns(name) values(?);";
        this.stmt = connection.prepareStatement(query);
        this.stmt.setString(1, townName);
        stmt.executeUpdate();
    }

    private int getEnityIdByName(String tableName, String entityName) throws SQLException {
        query = String.format("select id from %s where name = ?", tableName);
        this.stmt = connection.prepareStatement(query);
        this.stmt.setString(1, entityName);
        this.stmt.execute();
        ResultSet resultSet = stmt.getResultSet();

        return resultSet.next() ? resultSet.getInt(1) : -1;
    }


    public void deleteVillains() throws SQLException {
        System.out.println("Enter villain's ID: ");
        int villainId = Integer.parseInt(sc.nextLine());
        try {
            String name = getEntityNameById(villainId, "villains");
            System.out.println(name + " was deleted");
            try {
                this.query = "select count(minion_id) from minions_villains as mv\n" +
                        "group by villain_id\n" +
                        "having villain_id = ?;";
                this.stmt = connection.prepareStatement(query);
                this.stmt.setInt(1, villainId);
                this.stmt.execute();
                ResultSet rs = stmt.getResultSet();
                rs.next();
                int count = rs.getInt(1);

                dropConstraint();

                query = "delete from villains where id = ?";
                this.stmt = connection.prepareStatement(query);
                this.stmt.setInt(1, villainId);
                this.stmt.execute();
                System.out.println(count + " minions released");
            } catch (SQLException e) {
                System.out.println("0 minions released");
            }


            return;
        } catch (SQLException e) {
            System.out.println("No such villain was found");
            return;
        }
    }

    private void dropConstraint() throws SQLException {

        query = "alter table minions_villains " +
                "drop foreign key  minions_villains_ibfk_1;";
        /** TODO minions_villains_ibfk_1 е името на foreign key -а в моята база(защото правих други работи с него)
         твоят трябва да е със следното наименование: fk_villains_minions */
        this.stmt = connection.prepareStatement(query);
        this.stmt.execute();

        query = "alter table minions_villains " +
                "add foreign key fk_villains_minions(villain_id) " +
                "references villains(id) " +
                "ON DELETE cascade ;";
        this.stmt = connection.prepareStatement(query);
        this.stmt.execute();

    }

    public void printAllMinionNames() throws SQLException {
        query = "select name from minions";
        this.stmt = connection.prepareStatement(query);
        this.stmt.execute();
        ResultSet rs = this.stmt.getResultSet();
        List<String> names = new ArrayList<>();
        while (rs.next()){
            names.add(rs.getString("name"));
        }

        List<String> namesOdd = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) {
            String current = names.get(i);
            if (i % 2 != 0) {
                namesOdd.add(current);
            }
        }

        for (int i = 0; i < names.size(); i++) {
            if (i % 2 == 0){
                System.out.println(names.get(i));
            }else {
                System.out.println(namesOdd.get(namesOdd.size() - i));
                System.out.println(names.get(i));
            }
        }

    }

    public void increaseAgeWithStoredProcedure() throws SQLException {
        System.out.println("Enter minion id: ");
        int id = Integer.parseInt(sc.nextLine());
        CallableStatement statement = connection.prepareCall("call usp_get_older(?)");
        statement.execute();
    }

    public void increaseMinionAge() throws SQLException {
        System.out.println("Enter minions ids: ");
        int[] minIds = Arrays.stream(sc.nextLine().split("\\s+")).mapToInt(Integer::parseInt).toArray();
        for (int id : minIds) {
            query = "update minions set age = age +1,name = lower(name) where id = ?";
            this.stmt = connection.prepareStatement(query);
            this.stmt.setInt(1,id);
            this.stmt.executeUpdate();
        }
        query = "select name, age from minions order by id;";
        this.stmt = connection.prepareStatement(query);
        this.stmt.execute();
        ResultSet rs = this.stmt.getResultSet();
        while (rs.next()){
            System.out.println(rs.getString("name") + " " + rs.getInt("age"));
        }
    }
}
