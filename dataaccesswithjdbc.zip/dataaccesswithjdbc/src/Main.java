import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    private static  String USERNAME = "";
    private static  String PASSWORD = "";
    private static Homework h;

    public static void main(String[] args) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        h = new Homework();

        System.out.println("Enter your DB username: ");
        USERNAME = scanner.nextLine();
        System.out.println("Enter your DB password: ");
        PASSWORD  = scanner.nextLine();

        h.getConnection(USERNAME, PASSWORD);

//        printOutput();
        userChoice(scanner);
    }

    private static void userChoice(Scanner sc) throws SQLException {
        String line = sc.nextLine();
        while (!line.equals("")){
            int number = Integer.parseInt(line);
            switch (number){
                case 1:
                    h.getVillainsNames();
                    break;
                case 2:
                    h.getMinionNames();
                    break;
                case 3:
                    h.addMinion();
                    // трябва да се рънва по два пъти, заради ексепшън, който реве от foreign keys на миньоните/злодеите
                    // (не може да се добавя запис при child row)
                    // в minions_villains
                    // кода иначе си работи и ги вкарва както трябва
                    break;
                case 4:
                    h.changeTownNamesCasing();
                    break;
                case 5:
                    h.deleteVillains();
                    break;
                case 6:
                    h.printAllMinionNames();
                    break;
                case 7:
                    h.increaseMinionAge();
                    break;
                case 8:
                    h.increaseAgeWithStoredProcedure();
                    break;
            }
            line = sc.nextLine();
        }
        System.out.println("Come back soon!");
    }

    private static void printOutput() {
        System.out.println("Welcome to yocalee's homework");
        System.out.println("Please press -----------------------");
        System.out.println("1 for second exercise");
        System.out.println("2 for third exercise");
        System.out.println("3 for fourth exercise");
        System.out.println("4 for fifth exercise");
        System.out.println("5 for sixth exercise");
        System.out.println("6 for seventh exercise");
        System.out.println("7 for eight exercise");
        System.out.println("8 for ninth exercise");
    }

}
